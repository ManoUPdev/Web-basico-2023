function toggleMenu() {
    const navList = document.querySelector('.nav-list');
    navList.classList.toggle('show');
}

function showContent(contentId) {
    const allAbas = document.querySelectorAll('.aba');
    allAbas.forEach(aba => {
        aba.style.display = 'none';
    });

    const selectedAba = document.getElementById(contentId);
    if (selectedAba) {
        selectedAba.style.display = 'block';
    }
}